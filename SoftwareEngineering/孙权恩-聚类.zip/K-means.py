# %%
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from random import randint

# %%
df = pd.read_csv("dataset_circles.csv")
df = df[['x','y']]
df['lable'] = np.zeros(len(df.index))
#print(df.loc[1]['x'])
#print(df.columns)
#print(df[df.lable==0].mean()['x'])
# 总点数
N = len(df.index)


# %%
# 聚类数
K = 2
dot1, dot2 = randint(0,N-1), randint(0,N-1)
#print(dot1, dot2)
nxt_centroids = [[df.loc[dot1]['x'], df.loc[dot1]['y']], [df.loc[dot2]['x'], df.loc[dot2]['y']]]
#print(nxt_centroids)
centroids = []

# %%
itreation = 0
while centroids != nxt_centroids:
    #print('itreation: {}'.format(itreation))
    #print('centroids = {}'.format(nxt_centroids))
    itreation = itreation+1
    centroids = list(nxt_centroids)
    nxt_centroids.clear()
    for i in range(0,N):
        x,y = df.loc[i][:2]
        distances = []
        for centroid in centroids:
            distances.append(np.sqrt((x-centroid[0])**2 + (y-centroid[1])**2))
        lable = np.argmin(distances)
        #print(distances)
        #print(lable)
        df.loc[i, 'lable'] = lable
    nxt_centroids.append([df[df.lable==0].mean()['x'], df[df.lable==0].mean()['y']])
    nxt_centroids.append([df[df.lable==1].mean()['x'], df[df.lable==1].mean()['y']])

# %%
#print(df[['x','y']])
plt.scatter(df[df.lable==0]['x'],df[df.lable==0]['y'], color='r')
plt.scatter(df[df.lable==1]['x'],df[df.lable==1]['y'], color='b')




